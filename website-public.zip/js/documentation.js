import { store } from './services/store-service.js';
import { $, esc, state, toast, supportUrl } from './ui.js';
import { customerGuides } from './data/customer-docs.js';

export async function renderDocs() {
  const requested = new URLSearchParams(location.search).get('product');
  const guideFor = id => customerGuides.find(guide => guide.productIds.includes(String(id)));
  const initialGuide = requested ? guideFor(requested) : customerGuides[0];
  let entries = customerGuides.map(guide => ({ id: guide.productIds[0], name: guide.title, guide }));
  const activeId = initialGuide?.productIds[0] || requested;
  const sidebar = $('#docs-sidebar-links'), article = $('#docs-article');

  function filterSidebar() {
    const term = $('#docs-search').value.trim().toLowerCase(); let count = 0;
    sidebar.querySelectorAll('a').forEach(link => { link.hidden = !link.textContent.toLowerCase().includes(term); if (!link.hidden) count++; });
    $('#docs-search-state').textContent = count ? '' : 'No documentation matches your search.';
  }
  function renderSidebar() {
    sidebar.innerHTML = entries.map(entry => `<a href="documentation.html?product=${encodeURIComponent(entry.id)}" ${entry.id === activeId ? 'aria-current="page"' : ''}>${esc(entry.name)}${entry.guide ? `<small class="docs-resource-version">v${esc(entry.guide.version)}</small>` : ''}</a>`).join('');
    filterSidebar();
  }
  function renderGuide(guide) {
    document.title = `${guide.title} v${guide.version} Documentation | Mr. Impulse Labs`;
    document.querySelector('meta[name=description]').content = `Installation, configuration, player workflows, and troubleshooting for ${guide.title} v${guide.version}.`;
    document.querySelector('meta[property="og:title"]').content = document.title;
    document.querySelector('meta[property="og:description"]').content = document.querySelector('meta[name=description]').content;
    const contents = guide.sections.map(section => `<a href="#${esc(section.id)}">${esc(section.title)}</a>`).join('');
    $('#docs-toc').innerHTML = '<h2>ON THIS PAGE</h2>' + contents;
    article.innerHTML = `<span class="eyebrow">CUSTOMER RESOURCE GUIDE</span><h2>${esc(guide.title)}</h2><p class="docs-version">Version ${esc(guide.version)} · Resource folder: <code>impulse_hotshot</code></p><details class="docs-guide-contents"><summary>In this guide</summary><nav aria-label="Guide sections">${contents}</nav></details>${guide.sections.map((section, i) => `<section id="${esc(section.id)}"><h3>${i + 1}. ${esc(section.title)}</h3>${section.html}<nav class="docs-section-nav" aria-label="${esc(section.title)} section navigation">${i ? `<a href="#${esc(guide.sections[i - 1].id)}">← ${esc(guide.sections[i - 1].title)}</a>` : '<span></span>'}${i < guide.sections.length - 1 ? `<a href="#${esc(guide.sections[i + 1].id)}">${esc(guide.sections[i + 1].title)} →</a>` : '<a href="#overview">Back to overview ↑</a>'}</nav></section>`).join('')}<p class="docs-support">Need help with your setup? <a href="${esc(supportUrl())}" target="_blank" rel="noopener noreferrer">Open a ticket in our Discord →</a></p>`;
  }
  function renderUnavailable(entry) {
    $('#docs-toc').innerHTML = '';
    article.innerHTML = entry ? `<span class="eyebrow">RESOURCE DOCUMENTATION</span><h2>${esc(entry.name)}</h2><p>An installation guide has not been published for this resource yet.</p><a class="text-link" href="${esc(supportUrl())}" target="_blank" rel="noopener noreferrer">Get support on Discord →</a>` : state('Documentation not found.');
  }

  $('#docs-search').addEventListener('input', filterSidebar);
  $('[data-docs-toggle]').onclick = e => { const open = !$('#docs-sidebar').classList.contains('open'); $('#docs-sidebar').classList.toggle('open', open); e.currentTarget.setAttribute('aria-expanded', String(open)); };
  article.addEventListener('click', async e => {
    const button = e.target.closest('[data-copy-code]'); if (!button) return;
    try { await navigator.clipboard.writeText(button.parentElement.querySelector('code').textContent); button.textContent = 'Copied'; button.setAttribute('aria-label', 'Code example copied'); setTimeout(() => { button.textContent = 'Copy'; button.setAttribute('aria-label', 'Copy code example'); }, 2000); }
    catch { toast('Copy is unavailable here. Select the code and copy it manually.'); }
  });
  renderSidebar();
  if (initialGuide) renderGuide(initialGuide);
  else article.innerHTML = '<p class="loading" role="status">Opening the resource guide…</p>';
  // Local customer guides remain available even during an unrelated store outage.
  try {
    const products = await store.getProducts();
    for (const product of products) {
      const guide = guideFor(product.id) || guideFor(product.numericId);
      if (!guide) entries.push({ id: product.id, name: product.name });
    }
    renderSidebar();
    if (!initialGuide) renderUnavailable(entries.find(entry => entry.id === requested));
  } catch (error) {
    if (!initialGuide) article.innerHTML = state(error.message, true);
  }
}
