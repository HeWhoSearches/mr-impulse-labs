import { store } from './services/store-service.js';
import { siteConfig } from './config.js';
import { esc, toast } from './ui.js';
import { officialUrl } from './services/tebex-adapter.js';

const root = new URL('../', import.meta.url);
let dialog, busy = false, signedOut = false;
async function identities({ includeOptionalDiscord = false } = {}) {
  const basket = await store.getBasket();
  let discord = { configured: false, connected: false };
  if (!siteConfig.auth.requireDiscord && !includeOptionalDiscord) return { basket, discord, ready: basket.authenticated };
  try {
    const response = await fetch(new URL('api/auth/session', root), { credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(5000) });
    if (response.ok) discord = (await response.json()).discord;
  } catch { /* Static hosting cannot provide a verified Discord session. */ }
  return { basket, discord, ready: basket.authenticated && (!siteConfig.auth.requireDiscord || discord?.connected === true) };
}
function render({ basket, discord, ready }) {
  const intro = basket.authenticated ? 'Manage your Cfx.re connection for this store.' : signedOut ? 'Connect Cfx.re to start a new cart.' : `${siteConfig.auth.requireDiscord ? 'Connect Cfx.re and Discord to continue.' : 'Sign in with Cfx.re to continue.'} Your selected product will be added automatically, then you’ll go straight to your cart.`;
  const discordSection = siteConfig.auth.requireDiscord || discord?.configured || discord?.connected
    ? `<section class="login-provider"><h3>Discord${siteConfig.auth.requireDiscord ? '' : ' · Optional'}</h3><p>${discord?.connected ? 'Connected: ' + esc(discord.displayName) : discord?.configured ? 'Connect your Discord account.' : 'Discord sign-in is awaiting store setup.'}</p>${discord?.connected ? '<span class="badge">Connected ✓</span>' : discord?.configured ? '<a class="button secondary full" href="' + new URL('api/auth/discord/start', root).href + '">Connect Discord ↗</a>' : ''}</section>`
    : '';
  dialog.querySelector('[data-login-content]').innerHTML = `<p class="checkout-note">${intro}</p><section class="login-provider"><h3>Cfx.re / FiveM</h3><p>${basket.authenticated ? 'Connected' + (basket.displayName ? ': ' + esc(basket.displayName) : '') : 'Sign in securely through Tebex to connect your Cfx.re account.'}</p>${basket.authenticated ? '<span class="badge">Connected ✓</span><button class="button secondary full" data-sign-out style="margin-top:14px">Sign out</button><p class="checkout-note">Signing out disconnects this store and clears this cart.</p>' : '<button class="button secondary full" data-connect-cfx>Connect Cfx.re ↗</button>'}</section>${discordSection}${signedOut && !basket.authenticated ? '<p class="checkout-note">Signed out of this store. To use a different Cfx.re account, <a class="text-link" href="https://forum.cfx.re/" target="_blank" rel="noopener noreferrer">sign out on Cfx.re first ↗</a>, then connect again here.</p>' : ''}<p class="checkout-message" data-login-message role="status"></p>`;
  document.querySelectorAll('[data-open-login]').forEach(button => { button.title = ready ? 'Connected accounts' : 'Sign in'; button.setAttribute('aria-label', button.title); });
}
export async function ensureSignedIn(productId) {
  if (siteConfig.store.mode !== 'live') return true;
  if (productId) store.rememberPendingProduct(productId);
  const value = await identities();
  if (value.ready) { if (dialog.open) dialog.close(); return true; }
  render(value);
  document.querySelectorAll('dialog[open]').forEach(other => { if (other !== dialog) other.close(); });
  if (!dialog.open) dialog.showModal();
  return false;
}
export async function resumeSignedIn() {
  if (!await ensureSignedIn()) return false;
  const result = await store.resumePendingAdd();
  if (result?.requiresAuth) { await ensureSignedIn(); return false; }
  if (dialog.open) dialog.close();
  if (result) {
    toast('Added to your Tebex basket.');
    document.dispatchEvent(new Event('basket-updated'));
    const basketUrl = new URL('basket.html', root);
    if (location.pathname !== basketUrl.pathname) location.assign(basketUrl.href);
  }
  return true;
}
export function initAuthentication() {
  document.body.insertAdjacentHTML('beforeend', '<dialog id="login-dialog" class="login-dialog" aria-labelledby="login-title"><div class="dialog-heading"><h2 id="login-title">Your account<span class="cyan-text">.</span></h2><button class="icon-button" data-close aria-label="Close sign-in">×</button></div><div data-login-content></div></dialog>');
  dialog = document.querySelector('#login-dialog');
  document.addEventListener('click', async event => {
    const open = event.target.closest('[data-open-login], [data-auth]');
    const cfx = event.target.closest('[data-connect-cfx]');
    const signOut = event.target.closest('[data-sign-out]');
    if ((!open && !cfx && !signOut) || busy) return;
    busy = true;
    const button = open || cfx || signOut; button.disabled = true;
    try {
      if (open) { const value = await identities({ includeOptionalDiscord: true }); render(value); document.querySelectorAll('dialog[open]').forEach(other => { if (other !== dialog) other.close(); }); if (!dialog.open) dialog.showModal(); }
      if (signOut) {
        await store.signOut();
        signedOut = true;
        document.dispatchEvent(new Event('basket-updated'));
        render(await identities({ includeOptionalDiscord: true }));
        document.querySelectorAll('dialog[open]').forEach(other => { if (other !== dialog) other.close(); });
        if (!dialog.open) dialog.showModal();
        toast('Signed out of this store. Your cart has been cleared.');
      }
      if (cfx) {
        cfx.textContent = 'Opening Cfx.re…';
        const result = await store.getAuthentication();
        if (result?.requiresAuth) {
          const provider = result.authLinks.find(link => /^(?:FiveM|Cfx(?:\.re)?)$/i.test(link.name.trim()));
          const url = officialUrl(provider?.url);
          if (!url) throw new Error('Tebex did not provide a Cfx.re sign-in link. Please try again or contact us on Discord.');
          // Use a fresh basket authorization URL from Tebex in this same tab.
          // The return rechecks the basket's identity; a callback alone is not proof.
          location.assign(url);
        } else await resumeSignedIn();
      }
    } catch (error) { const message = dialog.querySelector('[data-login-message]'); if (message) message.textContent = error.message; else toast(error.message); }
    finally { busy = false; button.disabled = false; if (cfx) cfx.textContent = 'Connect Cfx.re ↗'; }
  });
}
