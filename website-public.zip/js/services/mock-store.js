import { products } from '../data/mock-products.js';
import { categories } from '../data/mock-categories.js';
import { siteConfig } from '../config.js';
const key = 'impulse-demo-basket-v1';
let memory = [];
function read() { try { const value = JSON.parse(localStorage.getItem(key) || '[]'); return Array.isArray(value) ? [...new Set(value)].filter(id => products.some(p => p.id === id)) : []; } catch { return memory; } }
function save(ids) { memory = ids; try { localStorage.setItem(key, JSON.stringify(ids)); } catch { /* In-memory basket remains available. */ } }
function check() { if (siteConfig.store.simulateError) throw new Error('The demonstration store is temporarily unavailable. Please try again.'); }
export const mockStore = {
  async getCategories() { check(); return categories; },
  async getProducts() { check(); return products; },
  async getProductById(id) { check(); return products.find(p => p.id === id) || null; },
  async getFeaturedProducts() { check(); return products.filter(p => p.featured).slice(0, 6); },
  async getBasket() { check(); const items = read().map(id => ({ product: products.find(p => p.id === id), quantity: 1 })); return { items, subtotal: Math.round(items.reduce((sum, item) => sum + item.product.price, 0) * 100) / 100, currency: siteConfig.store.currency, simulated: true }; },
  async addToBasket(id) { check(); if (!products.some(p => p.id === id)) throw new Error('Product not found.'); save([...new Set([...read(), id])]); return this.getBasket(); },
  async removeFromBasket(id) { check(); save(read().filter(value => value !== id)); return this.getBasket(); },
  async beginCheckout() { throw new Error('Tebex checkout is not configured yet.'); },
};
