import { siteConfig } from '../config.js';
import { mockStore } from './mock-store.js';
import { tebexAdapter } from './tebex-adapter.js';
export const store = siteConfig.store.mode === 'mock' ? mockStore : tebexAdapter;
