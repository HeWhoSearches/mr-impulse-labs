import { siteConfig } from '../config.js';

const API = 'https://headless.tebex.io/api';
const enc = encodeURIComponent;
const amount = value => Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : 0;
export function httpsUrl(value) { try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password ? url.href : ''; } catch { return ''; } }
export function officialUrl(value) { const href = httpsUrl(value); if (!href) return ''; const { hostname } = new URL(href); return hostname === 'tebex.io' || hostname.endsWith('.tebex.io') ? href : ''; }
function plainText(value) {
  // API descriptions are HTML. Parse in an inert document and return text only.
  if (typeof DOMParser !== 'undefined') { const doc = new DOMParser().parseFromString(String(value || ''), 'text/html'); doc.querySelectorAll('script,style,iframe,object,template').forEach(node => node.remove()); doc.querySelectorAll('p,br,li,div,h1,h2,h3').forEach(node => node.append('\n')); return doc.body.textContent.replace(/\n\s*\n\s*\n/g, '\n\n').trim(); }
  return String(value || '').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}
export function normalizeProduct(raw, categoryId = '', featuredIds = []) {
  const rawPrice = raw.total_price ?? raw.base_price;
  if (rawPrice == null || !Number.isFinite(Number(rawPrice)) || Number(rawPrice) < 0) throw new Error('Tebex returned a resource without a valid price.');
  const id = String(raw.ident || raw.id);
  const images = [...new Set([raw.image, ...(raw.media || []).filter(m => m.type === 'image').map(m => m.url)].map(httpsUrl).filter(Boolean))];
  const description = plainText(raw.description);
  const video = (raw.media || []).find(m => m.type === 'video' && httpsUrl(m.url));
  return {
    id, numericId: raw.id == null ? null : String(raw.id), categoryId: String(raw.category?.id ?? categoryId),
    name: String(raw.name || 'Untitled resource'), price: amount(raw.total_price ?? raw.base_price), currency: /^[A-Z]{3}$/.test(raw.currency) ? raw.currency : siteConfig.store.currency,
    description, shortDescription: description.length > 150 ? `${description.slice(0, 147)}…` : description || 'View the resource details from Tebex.',
    compatibility: [], features: [], dependencies: [], changelog: [], version: '',
    images: images.length ? images : ['assets/images/fallback.svg'], videoUrl: httpsUrl(video?.url),
    featured: featuredIds.map(String).includes(id) || featuredIds.map(String).includes(String(raw.id)),
    accent: 'cyan', simulated: false, availability: 'Listed on Tebex',
    paymentType: raw.type === 'subscription' ? 'subscription' : raw.type === 'single' ? 'single' : '',
    requiresOptions: Boolean(raw.options?.length || raw.variables?.length),
  };
}

export function createTebexAdapter({ config = siteConfig.store, fetcher = (...args) => fetch(...args), storage = typeof sessionStorage === 'undefined' ? null : sessionStorage, location = typeof window === 'undefined' ? null : window.location } = {}) {
  const token = config.publicToken || '', account = `/accounts/${enc(token)}`, key = `impulse-tebex-${token}-v1`;
  let basketIdent = '', pendingProduct = '', catalogPromise, storePromise, mutation = Promise.resolve();
  function read(name) { try { return storage?.getItem(name) || ''; } catch { return ''; } }
  function write(name, value) { try { if (value) storage?.setItem(name, value); else storage?.removeItem(name); } catch { /* Active basket remains in memory. */ } }
  basketIdent = read(key); pendingProduct = read(`${key}-pending`);
  function forget() { basketIdent = ''; write(key, ''); setPending(''); catalogPromise = null; }
  function setPending(id) { pendingProduct = id; write(`${key}-pending`, id); }
  function queue(action) { const next = mutation.then(action, action); mutation = next.catch(() => {}); return next; }
  async function request(path, { method = 'GET', body, allow404 = false } = {}) {
    if (!token) throw new Error('Tebex public store token is not configured.');
    let response;
    try { response = await fetcher(`${API}${path}`, { method, credentials: 'omit', cache: 'no-store', headers: { Accept: 'application/json', ...(body ? { 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(15000) }); }
    catch { throw new Error('Could not reach Tebex. Check your connection and try again.'); }
    if (response.status === 404 && allow404) return null;
    if (!response.ok) { const error = new Error(response.status === 429 ? 'Tebex is busy. Please wait a moment before trying again.' : response.status === 401 || response.status === 403 ? 'Tebex requires sign-in or store configuration before this action can continue.' : 'Tebex could not complete this request. Please try again or contact support.'); error.status = response.status; throw error; }
    if (response.status === 204) return null;
    let payload; try { payload = await response.json(); } catch { throw new Error('Tebex returned an unreadable response. Please try again.'); }
    return payload?.data ?? payload;
  }
  async function getStoreInfo() {
    if (!storePromise) storePromise = request(account).then(raw => ({ name: String(raw.name || ''), currency: /^[A-Z]{3}$/.test(raw.currency) ? raw.currency : config.currency, url: httpsUrl(raw.webstore_url), platform: String(raw.platform_type || ''), hostedStoreDisabled: Boolean(raw.disabled) })).catch(error => { storePromise = null; throw error; });
    return storePromise;
  }
  async function catalog() {
    if (!catalogPromise) catalogPromise = (async () => {
      const query = basketIdent ? `&basketIdent=${enc(basketIdent)}` : '';
      const raw = await request(`${account}/categories?includePackages=1${query}`);
      if (!Array.isArray(raw)) throw new Error('Tebex returned an invalid catalog.');
      const categories = [], products = [], seenCategories = new Set(), seenProducts = new Set();
      function visit(category, inheritedParentId = null) {
        const id = String(category.id);
        const parent = typeof category.parent === 'object' ? category.parent?.id : category.parent;
        const parentId = parent == null ? inheritedParentId : String(parent);
        if (!seenCategories.has(id)) { categories.push({ id, name: String(category.name || 'Resources'), parentId, dynamic: Boolean(category.dynamic) }); seenCategories.add(id); }
        else if (parentId) categories.find(c => c.id === id).parentId = parentId;
        for (const rawProduct of category.packages || []) {
          const product = { ...normalizeProduct(rawProduct, id, config.featuredProductIds || []), dynamic: Boolean(category.dynamic) };
          if (!seenProducts.has(product.id)) { products.push(product); seenProducts.add(product.id); }
        }
        for (const child of category.children || []) visit(child, id);
      }
      raw.forEach(category => visit(category)); return { categories, products };
    })().catch(error => { catalogPromise = null; throw error; });
    return catalogPromise;
  }
  function emptyBasket(currency = config.currency) { return { items: [], subtotal: 0, tax: 0, total: 0, currency, simulated: false, created: false, authenticated: false }; }
  async function normalizeBasket(raw) {
    if (!raw || !Array.isArray(raw.packages)) throw new Error('Tebex returned an invalid basket.');
    const products = (await catalog()).products;
    const items = raw.packages.map(item => {
      const known = products.find(p => p.id === String(item.ident || item.id) || p.numericId === String(item.id));
      const quantity = Math.max(1, Math.floor(amount(item.in_basket?.quantity ?? item.quantity ?? 1)));
      const price = amount(item.in_basket?.price ?? item.base_price);
      return { product: known || normalizeProduct({ ...item, currency: raw.currency, base_price: price }), packageId: String(item.id ?? item.ident), quantity, price };
    });
    return { items, subtotal: amount(raw.base_price), tax: amount(raw.sales_tax), total: amount(raw.total_price), currency: /^[A-Z]{3}$/.test(raw.currency) ? raw.currency : config.currency, simulated: false, created: true, authenticated: Boolean(raw.username_id || raw.username), displayName: String(raw.username || ''), complete: Boolean(raw.complete), checkoutUrl: officialUrl(raw.links?.checkout) };
  }
  async function fetchRawBasket() {
    let raw;
    try { raw = await request(`${account}/baskets/${enc(basketIdent)}`, { allow404: true }); } catch (error) { if (error.status !== 422) throw error; }
    if (!raw) { forget(); const error = new Error('Your Tebex basket has expired. Please add your items again.'); error.expired = true; throw error; }
    if (raw.complete) { forget(); throw new Error('This basket has already been completed. Start a new basket to continue shopping.'); }
    return raw;
  }
  function returnUrl(state = '') {
    if (!location) throw new Error('A browser page is required to continue with Tebex.');
    const base = new URL('./', location.href);
    const url = new URL('basket.html', /\/(?:legal|privacy-policy|terms-of-service|refund-policy|anti-leaking-policy)\/$/.test(base.pathname) ? new URL('../', base) : base);
    if (state) url.searchParams.set('tebex', state);
    return url.href;
  }
  async function ensureBasket() {
    if (basketIdent) return fetchRawBasket();
    const raw = await request(`${account}/baskets`, { method: 'POST', body: { complete_url: returnUrl('return'), cancel_url: returnUrl('cancelled'), complete_auto_redirect: true } });
    if (!raw?.ident) throw new Error('Tebex did not return a basket identifier.');
    basketIdent = String(raw.ident); write(key, basketIdent); return raw;
  }
  async function authLinks() {
    const raw = await request(`${account}/baskets/${enc(basketIdent)}/auth?returnUrl=${enc(returnUrl('authenticated'))}`);
    if (!Array.isArray(raw)) throw new Error('Tebex did not return authentication options.');
    return raw.map(item => ({ name: String(item.name || 'Tebex'), url: officialUrl(item.url) })).filter(item => item.url);
  }
  async function authorization(raw, isReturn = false) {
    if (raw.username_id || raw.username) return null;
    const links = await authLinks();
    if (!links.length) throw new Error('Cfx.re sign-in is not available from Tebex. Please contact support.');
    if (isReturn) throw new Error('Tebex sign-in was not completed. Open the basket and sign in again to continue.');
    return { requiresAuth: true, authLinks: links };
  }
  async function add(id, isReturn = false) {
    const p = (await catalog()).products.find(p => p.id === String(id) || p.numericId === String(id));
    if (!p) throw new Error('This resource is no longer available from Tebex.');
    if (p.requiresOptions) throw new Error('This package requires additional options. Please contact support before purchasing.');
    const raw = await ensureBasket();
    setPending(p.id);
    const auth = await authorization(raw, isReturn); if (auth) return auth;
    if (raw.packages?.some(item => String(item.ident || item.id) === p.id || String(item.id) === p.numericId)) { setPending(''); return normalizeBasket(raw); }
    await request(`/baskets/${enc(basketIdent)}/packages`, { method: 'POST', body: { package_id: p.id, quantity: 1, ...(p.dynamic ? { dynamic: true } : {}) } });
    setPending(''); return normalizeBasket(await fetchRawBasket());
  }
  return {
    getStoreInfo,
    async getCategories() { return (await catalog()).categories; },
    async getProducts() { return (await catalog()).products; },
    async getProductById(id) { return (await catalog()).products.find(p => p.id === String(id) || p.numericId === String(id)) || null; },
    async getFeaturedProducts() { const products = (await catalog()).products; const featured = products.filter(p => p.featured); return (featured.length ? featured : products).slice(0, 6); },
    async getBasket() {
      if (!basketIdent) return emptyBasket((await getStoreInfo()).currency);
      try { return await normalizeBasket(await fetchRawBasket()); } catch (error) { if (error.expired) return { ...emptyBasket(), message: error.message }; throw error; }
    },
    addToBasket(id) { return queue(() => add(id)); },
    rememberPendingProduct(id) { setPending(String(id)); },
    removeFromBasket(id) { return queue(async () => {
      if (!basketIdent) return emptyBasket();
      const raw = await fetchRawBasket();
      // Catalog cards use opaque idents; basket rows may contain only numeric IDs.
      const products = (await catalog()).products;
      const product = products.find(p => p.id === String(id) || p.numericId === String(id));
      const item = raw.packages.find(item => [item.ident, item.id].filter(value => value != null).some(value => String(value) === String(id) || (product && (String(value) === product.id || String(value) === product.numericId))));
      if (!item) throw new Error('This item is no longer in the cart. Refresh the cart and try again.');
      const packageId = String(item.id ?? item.ident);
      await request(`/baskets/${enc(basketIdent)}/packages/remove`, { method: 'POST', body: { package_id: packageId } });
      if (product && (pendingProduct === product.id || pendingProduct === product.numericId)) setPending('');
      const updated = await fetchRawBasket();
      if (updated.packages.some(item => String(item.id ?? item.ident) === packageId)) throw new Error('Tebex has not removed this item yet. Please try again.');
      return normalizeBasket(updated);
    }); },
    signOut() { return queue(async () => { forget(); return emptyBasket(); }); },
    async getAuthentication() { const raw = await ensureBasket(); return await authorization(raw) || { requiresAuth: false }; },
    resumePendingAdd() { return queue(async () => { catalogPromise = null; if (!pendingProduct) return null; return add(pendingProduct, true); }); },
    async beginCheckout() { if (!basketIdent) throw new Error('Add a resource to your basket before checkout.'); const raw = await fetchRawBasket(); if (!raw.packages?.length) throw new Error('Add a resource to your basket before checkout.'); const auth = await authorization(raw); if (auth) return auth; const url = officialUrl(raw.links?.checkout); if (!url) throw new Error('Tebex checkout is not available for this basket yet.'); return { checkoutUrl: url }; },
  };
}
export const tebexAdapter = createTebexAdapter();
