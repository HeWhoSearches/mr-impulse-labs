export const siteConfig = {
  name: 'Mr. Impulse Labs',
  tagline: 'Built With Passion. Powered by Impulse.',
  baseUrl: '', // Set to the final HTTPS origin, including any subdirectory.
  social: { discord: 'https://discord.gg/Y5fxaBaXcN', youtube: '', twitch: '', github: '', tebex: '' },
  auth: { requireDiscord: false }, // Cfx.re is required; Discord can be enabled after setup.
  store: {
    provider: 'tebex', mode: 'live', currency: 'USD', simulateError: false,
    // Verified PUBLIC Headless store token. Never put a Tebex private key here.
    publicToken: '151ws-19ce8697aca15dd4aebd5c4a5be2068bd8b43b5f',
    featuredProductIds: [],
  },
};
