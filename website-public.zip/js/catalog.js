import { store } from './services/store-service.js';
import { $, esc, money, productCard, state } from './ui.js';
import { siteConfig } from './config.js';
import { categoryTree, categoryFamily } from './categories.js';
export async function renderCatalog() {
  $('#catalog-controls').addEventListener('submit', e => e.preventDefault());
  $('[data-filter-toggle]').onclick = e => { const open = !$('#filters').classList.contains('open'); $('#filters').classList.toggle('open', open); e.currentTarget.setAttribute('aria-expanded', String(open)); };
  const host = $('#catalog-results'); host.innerHTML = '<p class="loading" role="status">Opening the experiments cabinet…</p>';
  try {
    const [products, categories] = await Promise.all([store.getProducts(), store.getCategories()]);
    const priceSlider = $('#price-filter');
    const currency = products[0]?.currency || siteConfig.store.currency;
    const comparablePrices = new Set(products.map(p => p.currency || siteConfig.store.currency)).size <= 1;
    const priceCeiling = Math.max(1, Math.ceil(Math.max(0, ...products.map(p => p.price))));
    priceSlider.max = String(priceCeiling);
    priceSlider.defaultValue = String(priceCeiling);
    priceSlider.value = String(priceCeiling);
    priceSlider.disabled = !products.length || !comparablePrices;
    $('#price-range-end').textContent = money(priceCeiling, currency);
    const option = (c, label = c.name) => `<label><input type="checkbox" name="category" value="${esc(c.id)}">${esc(label)}</label>`;
    function branch({ category, children }) {
      if (!children.length) return option(category);
      const hasDirectProducts = products.some(p => p.categoryId === category.id);
      return `<fieldset class="category-group"><legend>${esc(category.name)}</legend>${hasDirectProducts ? option(category, `All ${category.name}`) : ''}<div class="category-children">${children.map(branch).join('')}</div></fieldset>`;
    }
    $('#category-filters').innerHTML = categoryTree(categories).map(branch).join('');
    const initial = new URLSearchParams(location.search).get('category');
    if (initial) { const family = categoryFamily(categories, initial); document.querySelectorAll('[name=category]').forEach(input => input.checked = family.has(input.value)); }
    function update() {
      const term = $('#search').value.trim().toLowerCase(), selected = [...document.querySelectorAll('[name=category]:checked')].map(input => input.value), price = Number(priceSlider.value);
      const anyPrice = priceSlider.disabled || price >= priceCeiling;
      const priceLabel = anyPrice ? 'Any price' : price === 0 ? 'Free only' : `Up to ${money(price, currency)}`;
      $('#price-value').textContent = priceLabel;
      priceSlider.setAttribute('aria-valuetext', priceLabel);
      priceSlider.style.setProperty('--range-progress', `${price / priceCeiling * 100}%`);
      const selectedIds = new Set(selected.flatMap(id => [...categoryFamily(categories, id)]));
      const found = products.filter(p => (!term || `${p.name} ${p.shortDescription} ${p.compatibility.join(' ')}`.toLowerCase().includes(term)) && (!selected.length || selectedIds.has(p.categoryId)) && (anyPrice || Math.round(p.price * 100) <= price * 100));
      const sorting = $('#sort').value; found.sort((a, b) => sorting === 'az' ? a.name.localeCompare(b.name) : sorting === 'za' ? b.name.localeCompare(a.name) : sorting === 'low' ? a.price - b.price : b.price - a.price);
      $('#result-count').textContent = `${found.length} ${found.length === 1 ? 'resource' : 'resources'} found · ${siteConfig.store.mode === 'mock' ? 'demonstration catalog' : 'Tebex catalog'}`;
      host.innerHTML = found.length ? found.map(p => productCard(p, categories)).join('') : state(products.length ? 'No experiments match those filters.' : 'New resources are on the way.', false, { href: 'support.html', label: 'Get support →' });
    }
    $('#catalog-controls').addEventListener('input', update); $('#catalog-controls').addEventListener('change', update);
    $('#clear-filters').onclick = () => { $('#catalog-controls').reset(); update(); };
    update();
  } catch (error) { host.innerHTML = state(error.message, true); }
}
