import { $ } from './ui.js';
export function initNavigation() {
  const button = $('[data-menu]'), nav = $('#navigation');
  function close() { button.setAttribute('aria-expanded', 'false'); button.setAttribute('aria-label', 'Open navigation'); nav.classList.remove('open'); }
  button.addEventListener('click', () => { const open = button.getAttribute('aria-expanded') !== 'true'; button.setAttribute('aria-expanded', String(open)); button.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation'); nav.classList.toggle('open', open); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && nav.classList.contains('open')) { close(); button.focus(); } });
  document.addEventListener('click', e => { if (!e.target.closest('header')) close(); });
  nav.addEventListener('click', e => { if (e.target.closest('a')) close(); });
  document.addEventListener('focusin', e => { if (!e.target.closest('header')) close(); });
  matchMedia('(min-width:851px)').addEventListener('change', close);
}
