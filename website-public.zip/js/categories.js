// Tebex may return a flat list with parent objects or nested children.
// The adapter normalizes both into parentId relationships.
export function categoryTree(categories) {
  const nodes = new Map(categories.map(category => [category.id, { category, children: [] }]));
  const roots = [];
  for (const node of nodes.values()) {
    const parent = nodes.get(node.category.parentId);
    if (parent && parent !== node) parent.children.push(node);
    else roots.push(node);
  }
  return roots;
}

export function categoryFamily(categories, id) {
  const found = new Set([String(id)]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const category of categories) {
      if (found.has(category.parentId) && !found.has(category.id)) { found.add(category.id); changed = true; }
    }
  }
  return found;
}
