import { siteConfig } from './config.js';
import { $, esc, social, productCard, state, safeUrl } from './ui.js';
import { store } from './services/store-service.js';
import { initNavigation } from './navigation.js';
import { initAuthentication } from './authentication.js';
import { initBasket } from './basket.js';
import { renderCatalog } from './catalog.js';
import { renderProduct } from './product-detail.js';
import { renderDocs } from './documentation.js';
import { categoryTree } from './categories.js';
const page = document.body.dataset.page, legal = document.body.dataset.legal === 'true';
const prefix = legal ? '../' : '';
const navigation = [['home', 'Home', 'index.html'], ['scripts', 'Scripts', 'scripts.html'], ['documentation', 'Documentation', 'documentation.html'], ['support', 'Support', 'support.html'], ['about', 'About', 'about.html']];
const brand = `<a class="brand" href="${prefix}index.html" aria-label="Mr. Impulse Labs home"><img src="${prefix}assets/images/mascot-160.webp" alt="" width="53" height="53"><strong>MR. IMPULSE<span>LABS</span></strong></a>`;
const bag = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/></svg>';
$('#site-header').innerHTML = `<div class="container header-inner">${brand}<nav class="nav" id="navigation" aria-label="Main navigation">${navigation.map(([key, label, href]) => `<a href="${prefix}${href}" ${key === page || (page === 'product' && key === 'scripts') ? 'aria-current="page"' : ''}>${label}</a>`).join('')}${social('discord', 'Discord', 'nav-discord')}</nav><div class="header-actions"><button class="icon-button login-button" data-open-login aria-label="Sign in" title="Sign in"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/></svg></button><button class="icon-button basket-button" data-open-basket aria-label="Open basket">${bag}<span class="count" data-count aria-live="polite">0</span></button><button class="icon-button menu-button" data-menu aria-controls="navigation" aria-expanded="false" aria-label="Open navigation">☰</button></div></div>`;
const communityLinks = ['discord', 'youtube', 'twitch', 'github', 'tebex'].map(name => social(name, name[0].toUpperCase() + name.slice(1), '')).join('');
$('#site-footer').innerHTML = `<div class="container"><div class="footer-grid"><div class="footer-brand">${brand}<p>Built With Passion.<br>Powered by Impulse.</p></div><div><h3>EXPLORE THE LAB</h3>${navigation.map(([, label, href]) => `<a href="${prefix}${href}">${label}</a>`).join('')}</div><div>${communityLinks ? `<h3>FIND YOUR PEOPLE</h3>${communityLinks}` : '<h3>THE COMMUNITY</h3><p style="font-size:.75rem">Community links will appear here when configured.</p>'}</div><div><h3>THE FINE PRINT</h3><a href="${prefix}privacy-policy/">Privacy Policy</a><a href="${prefix}terms-of-service/">Terms of Service</a><a href="${prefix}refund-policy/">Refund Policy</a><a href="${prefix}anti-leaking-policy/">Anti-Leaking Policy</a></div></div><div class="footer-bottom"><span>© ${new Date().getFullYear()} Mr. Impulse Labs. Independent developer.</span><span>Not affiliated with Rockstar Games, Cfx.re, or Tebex.</span></div></div>`;
document.body.insertAdjacentHTML('beforeend', `<dialog id="basket-dialog" class="basket-dialog" aria-labelledby="basket-title"><div class="dialog-heading"><h2 id="basket-title">Your basket<span class="cyan-text">.</span></h2><button class="icon-button" data-close aria-label="Close basket">×</button></div><div data-basket-content></div></dialog><dialog id="lightbox" class="lightbox" aria-label="Image preview"><div class="dialog-heading"><span>Inside the lab</span><button class="icon-button" data-close aria-label="Close image preview">×</button></div><img id="lightbox-image" alt=""></dialog><div id="toast" role="status" aria-live="polite"></div>`);
document.addEventListener('click', e => { const close = e.target.closest('[data-close]'); if (close) close.closest('dialog').close(); if (e.target.matches('dialog')) { const rect = e.target.getBoundingClientRect(); if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) e.target.close(); } if (e.target.closest('[data-retry]')) location.reload(); });
document.addEventListener('error', e => { if (e.target instanceof HTMLImageElement && !e.target.dataset.fallback) { e.target.dataset.fallback = 'true'; e.target.src = `${prefix}assets/images/fallback.svg`; } }, true);
document.querySelectorAll('[data-social=discord]').forEach(host => host.innerHTML = social('discord', host.dataset.label || 'Join Our Discord') || '<p class="muted" style="font-size:.78rem">Discord invite coming soon. Community links are awaiting configuration.</p>');
// Keep old support-page bookmarks usable; every support action opens Discord.
document.querySelectorAll('a[href]').forEach(link => {
  if (/^(\.\.\/)?support\.html(?:[?#].*)?$/.test(link.getAttribute('href'))) {
    link.href = safeUrl(siteConfig.social.discord) || `${prefix}support.html`;
    if (safeUrl(siteConfig.social.discord)) { link.target = '_blank'; link.rel = 'noopener noreferrer'; link.removeAttribute('aria-current'); }
  }
});
initNavigation(); initAuthentication(); initBasket();
// Canonical and social URLs are emitted only after the real origin is configured.
if (safeUrl(siteConfig.baseUrl)) {
  const base = new URL(siteConfig.baseUrl.endsWith('/') ? siteConfig.baseUrl : `${siteConfig.baseUrl}/`);
  const name = document.body.dataset.policyRoute || (legal ? `legal/${location.pathname.split('/').pop()}` : location.pathname.split('/').pop() || 'index.html');
  const url = new URL(name, base); if (page === 'product') url.search = new URLSearchParams({ id: new URLSearchParams(location.search).get('id') || '' }).toString();
  const canonical = document.createElement('link'); canonical.rel = 'canonical'; canonical.href = url.href; document.head.append(canonical);
  document.querySelector('meta[property="og:url"]').content = url.href;
  document.querySelector('meta[property="og:image"]').content = new URL('assets/images/lab.webp', base).href;
}
async function home() { try { const [products, categories] = await Promise.all([store.getFeaturedProducts(), store.getCategories()]); $('#featured-products').innerHTML = products.length ? products.map(p => productCard(p, categories)).join('') : state('New experiments are on the way.'); $('#home-categories').innerHTML = categoryTree(categories).map(({ category: c }, i) => `<a class="category-link" href="scripts.html?category=${esc(c.id)}"><span aria-hidden="true">${['⌘', '◉', '◇', '⊕', '✦', '▧', '⌁'][i % 7]}</span>${esc(c.name)} <span aria-hidden="true">↗</span></a>`).join(''); } catch (error) { $('#featured-products').innerHTML = state(error.message, true); } }
if (page === 'home') home();
if (page === 'scripts') renderCatalog();
if (page === 'product') renderProduct();
if (page === 'documentation') renderDocs();

if (siteConfig.store.mode === 'live') {
  document.querySelectorAll('[data-commerce-note]').forEach(el => { el.textContent = 'Resources, availability, and pricing are provided by Tebex. New releases will appear as they are published.'; });
  if (page === 'basket') {
    const status = new URLSearchParams(location.search).get('tebex');
    if (status === 'return' || status === 'cancelled') {
      const notice = document.createElement('p'); notice.className = 'notice'; notice.setAttribute('role', 'status');
      notice.textContent = status === 'cancelled' ? 'You returned from checkout. No payment status is inferred here. You can review your basket below.' : 'You returned from Tebex. Check your Tebex receipt or account for the payment status; returning to this page does not confirm a purchase.';
      document.querySelector('.basket-page').before(notice);
    }
  }
} else {
  document.querySelectorAll('[data-commerce-note]').forEach(el => { el.textContent = 'Development storefront. Resources and prices are illustrative. No payments are accepted in mock mode.'; });
}
