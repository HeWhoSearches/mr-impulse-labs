import { store } from './services/store-service.js';
import { $, esc, money, toast, state } from './ui.js';
import { siteConfig } from './config.js';
import { ensureSignedIn, resumeSignedIn } from './authentication.js';
import { officialUrl } from './services/tebex-adapter.js';
const prefix = document.body.dataset.legal === 'true' ? '../' : '';
const live = siteConfig.store.mode === 'live';
function imageUrl(src) { return src.startsWith('https://') ? src : `${prefix}${src}`; }
function basketMarkup(basket) { return `${basket.simulated ? '<p class="notice">Development basket · demonstration prices only. No purchases or downloads are available.</p>' : '<p class="checkout-note">Your basket and payment totals are managed by Tebex.</p>'}${live && basket.authenticated ? `<div class="basket-account"><span>${basket.displayName ? esc(basket.displayName) : 'Cfx.re connected'}</span><button class="button secondary" data-sign-out>Sign out</button></div>` : ''}${basket.message ? `<p class="notice">${esc(basket.message)}</p>` : ''}${basket.items.length ? basket.items.map(({ product: p, packageId, quantity, price }) => `<article class="basket-item"><img src="${esc(imageUrl(p.images[0]))}" width="65" height="39" alt=""><div><h3><a href="${prefix}product.html?id=${encodeURIComponent(p.id)}">${esc(p.name)}</a></h3><p>${money(basket.simulated ? p.price : price, basket.currency)} · Qty ${quantity}</p></div><button class="icon-button remove" data-remove="${esc(packageId || p.id)}" aria-label="Remove ${esc(p.name)}">×</button></article>`).join('') : state('Your basket is taking a breather.')}<div class="basket-summary"><span>${basket.simulated ? 'Demo subtotal' : 'Subtotal'}</span><strong>${money(basket.subtotal, basket.currency)}</strong></div>${basket.simulated ? '' : `<div class="basket-summary"><span>Tax</span><strong>${money(basket.tax, basket.currency)}</strong></div><div class="basket-summary"><span>Total</span><strong>${money(basket.total, basket.currency)}</strong></div>`}${live && !basket.authenticated ? '<button class="button secondary full" data-auth>Connect your accounts ↗</button>' : ''}<button class="button full" data-checkout ${live && !basket.items.length ? 'disabled' : ''}>Continue to checkout <span aria-hidden="true">↗</span></button><p class="checkout-note">${basket.simulated ? 'Checkout will be provided by Tebex when connected.' : 'You’ll enter payment details on Tebex. Final pricing and eligibility are confirmed there.'}</p><p class="checkout-message" role="status"></p>`; }
export async function refreshBasket() {
  try { const basket = await store.getBasket(); document.querySelectorAll('[data-open-login]').forEach(button => { button.title = basket.authenticated ? 'Your account' : 'Sign in'; button.setAttribute('aria-label', button.title); }); document.querySelectorAll('[data-count]').forEach(el => el.textContent = basket.items.reduce((sum, item) => sum + item.quantity, 0)); document.querySelectorAll('[data-basket-content]').forEach(el => el.innerHTML = basketMarkup(basket)); } catch (e) { document.querySelectorAll('[data-count]').forEach(el => el.textContent = '0'); document.querySelectorAll('[data-basket-content]').forEach(el => el.innerHTML = state(e.message, true)); }
}
export function initBasket() {
  const dialog = $('#basket-dialog');
  document.addEventListener('click', async e => {
    const open = e.target.closest('[data-open-basket]'), add = e.target.closest('[data-add]'), remove = e.target.closest('[data-remove]'), checkout = e.target.closest('[data-checkout]');
    if (open) { await refreshBasket(); dialog.showModal(); }
    if (add || remove) { const button = add || remove; button.disabled = true; try { if (add && !await ensureSignedIn(add.dataset.add)) return; const result = await (add ? store.addToBasket(add.dataset.add) : store.removeFromBasket(remove.dataset.remove)); await refreshBasket(); if (result?.requiresAuth) { await ensureSignedIn(); } else if (remove) toast('Removed from your cart.'); else if (add) { toast(live ? 'Added to your Tebex basket.' : 'Added to your demo basket.'); location.assign(new URL('../basket.html', import.meta.url).href); } } catch (error) { toast(error.message); } finally { button.disabled = false; } }
    if (checkout) { const button = checkout, scope = button.closest('[data-basket-content]'); button.disabled = true; try { if (!await ensureSignedIn()) return; const result = await store.beginCheckout(); if (result?.requiresAuth) { await ensureSignedIn(); } else if (result?.checkoutUrl) { const url = officialUrl(result.checkoutUrl); if (!url) throw new Error('Tebex returned an invalid checkout destination.'); window.location.assign(url); } } catch (error) { const target = scope?.querySelector('.checkout-message'); if (target) target.textContent = error.message; else toast(error.message); } finally { button.disabled = false; } }
  });
  const query = new URLSearchParams(location.search);
  if (live && (query.get('tebex') === 'authenticated' || query.has('login'))) {
    if (query.has('login') && query.get('login') !== 'discord') toast('Discord sign-in was not completed. Please try again.');
    resumeSignedIn().then(refreshBasket).catch(error => toast(error.message));
    query.delete('login'); if (query.get('tebex') === 'authenticated') query.delete('tebex');
    history.replaceState(null, '', location.pathname + (query.size ? '?' + query : '') + location.hash);
  }
  document.addEventListener('basket-updated', refreshBasket);
  refreshBasket();
}
